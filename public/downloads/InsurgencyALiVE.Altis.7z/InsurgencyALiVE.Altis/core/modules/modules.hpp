#define cacheScript
#define gridMarkers
#define intelSpawn